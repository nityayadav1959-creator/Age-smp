# Age SMP Plugin (Paper 1.21.11, Java 21)

## Build
    mvn clean package
Copy `target/AgeSMP.jar` into your server's `plugins/` folder and restart.

## How it works
- Everyone starts at Age 10. Kill = +1 Age, death = -2 Age (configurable).
- Only ONE player can reach Age 100 and become GOD. Everyone else is capped at 99.
- Abilities come from the Ability Wand (blaze rod, auto-given):
  right-click = use, shift + right-click = switch ability.
  - Age 20: Obsidian Cage
  - Age 30: Lava Trap (3x3x3 lava box)
  - Age 40: Warrior Leap (high jump + landing smash)
  - Age 50: Titan Smash (next axe/mace hit deals huge damage)

## Commands
- /age, /age top, /age wand
- Admin (age.admin): /age start (3-2-1 then PVP ENABLED), /age stop, /age set <player> <age>, /age reset confirm, /age reload

Edit plugins/AgeSMP/config.yml for balance.

## Texture pack (made for Minecraft 1.21.11)
AgeSMP-ResourcePack.zip gives the Ability Wand a custom texture that changes colour with the
selected ability (gold = none, purple = Cage, orange = Lava, teal = Leap, red = Titan).
1. Upload the zip to a host with a direct download link (e.g. a GitHub release).
2. In config.yml set resource-pack.enabled: true and paste the url (sha1 is already filled in).
3. /age reload (new joins get the pack; rejoin to test). Keep it off if players don't have the pack,
   otherwise the wand shows a missing-texture block.
You can also just drop the zip into a player's resourcepacks folder to test singleplayer-style.

## No Java? Build online (GitHub)
1. Create a free GitHub repo and upload everything inside the AgeSMP folder
   (pom.xml, src, .github) to the repo root.
2. Open the repo > Actions tab > "Build AgeSMP" > wait for the green check.
3. Open the run > Artifacts > download AgeSMP-jar > unzip to get AgeSMP.jar.
4. Put AgeSMP.jar in your server's plugins/ folder and restart.
