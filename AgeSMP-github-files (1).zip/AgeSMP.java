package dev.agesmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.TileState;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Age SMP: everyone starts at Age 10. Kills = +Age, deaths = -Age.
 * Abilities unlock at Age 20 / 30 / 40 / 50. First to Age 100 becomes GOD.
 */
public class AgeSMP extends JavaPlugin implements Listener, TabExecutor {

    enum Ability {
        CAGE("Obsidian Cage", "cage"),
        LAVA("Lava Trap", "lava"),
        LEAP("Warrior Leap", "leap"),
        TITAN("Titan Smash", "titan");

        final String display;
        final String key;

        Ability(String display, String key) {
            this.display = display;
            this.key = key;
        }
    }

    private final Map<UUID, Integer> ages = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final Map<UUID, Integer> selected = new HashMap<>();
    private final Map<String, Long> cooldowns = new HashMap<>();
    private final Map<UUID, Long> titanUntil = new HashMap<>();
    private final Map<UUID, Long> noFallUntil = new HashMap<>();
    private final Map<UUID, Map<UUID, Long>> lastKill = new HashMap<>();
    private final Set<Location> protectedBlocks = new HashSet<>();
    private final List<TempBlocks> active = new ArrayList<>();

    private UUID god;
    private NamespacedKey wandKey;
    private File dataFile;

    // ------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        wandKey = new NamespacedKey(this, "ability_wand");
        dataFile = new File(getDataFolder(), "data.yml");
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("age")).setExecutor(this);

        // autosave every 5 minutes
        Bukkit.getScheduler().runTaskTimer(this, this::saveData, 6000L, 6000L);

        for (Player p : Bukkit.getOnlinePlayers()) {
            ages.putIfAbsent(p.getUniqueId(), startAge());
            names.put(p.getUniqueId(), p.getName());
            updateTab(p);
        }
    }

    @Override
    public void onDisable() {
        for (TempBlocks t : new ArrayList<>(active)) t.restore();
        saveData();
    }

    // ------------------------------------------------------------ config helpers

    private int ci(String path, int def) {
        return getConfig().getInt(path, def);
    }

    private double cd(String path, double def) {
        return getConfig().getDouble(path, def);
    }

    private int startAge() {
        return ci("start-age", 10);
    }

    private int godAge() {
        return ci("god-age", 100);
    }

    private int unlockAge(Ability a) {
        int def = switch (a) {
            case CAGE -> 20;
            case LAVA -> 30;
            case LEAP -> 40;
            case TITAN -> 50;
        };
        return ci("abilities." + a.key + ".age", def);
    }

    // ------------------------------------------------------------ message helpers

    private void msg(CommandSender s, String text, NamedTextColor color) {
        s.sendMessage(Component.text(text, color));
    }

    private void bar(Player p, String text) {
        p.sendActionBar(Component.text(text, NamedTextColor.YELLOW));
    }

    private void broadcast(String text, NamedTextColor color) {
        Bukkit.broadcast(Component.text(text, color));
    }

    // ------------------------------------------------------------ age system

    private int getAge(UUID id) {
        return ages.getOrDefault(id, startAge());
    }

    private List<Ability> unlocked(Player p) {
        int age = getAge(p.getUniqueId());
        List<Ability> list = new ArrayList<>();
        for (Ability a : Ability.values()) {
            if (age >= unlockAge(a)) list.add(a);
        }
        return list;
    }

    private void setAge(Player p, int target) {
        UUID id = p.getUniqueId();
        int old = getAge(id);
        boolean isGod = id.equals(god);

        // only one player can ever be Age 100 (GOD); everyone else is capped at 99
        int max = (god != null && !isGod) ? godAge() - 1 : godAge();
        target = Math.max(startAge(), Math.min(target, max));
        if (isGod) target = godAge(); // God never loses Age

        ages.put(id, target);
        names.put(id, p.getName());
        updateTab(p);
        if (target == old) return;

        if (target > old) {
            p.sendMessage(Component.text("You are now Age " + target, NamedTextColor.GREEN));
            for (Ability a : Ability.values()) {
                int u = unlockAge(a);
                if (old < u && target >= u) {
                    p.sendMessage(Component.text("ABILITY UNLOCKED: " + a.display + "!", NamedTextColor.GOLD));
                    p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                }
            }
            giveWandIfNeeded(p);

            int every = Math.max(1, ci("broadcast-every", 5));
            if (target / every > old / every && target < godAge()) {
                broadcast(p.getName() + " reached Age " + (target / every * every), NamedTextColor.YELLOW);
            }
            if (target >= godAge() && god == null) crown(p);
        } else {
            p.sendMessage(Component.text("You dropped to Age " + target, NamedTextColor.RED));
            for (Ability a : Ability.values()) {
                int u = unlockAge(a);
                if (old >= u && target < u) {
                    p.sendMessage(Component.text("You lost: " + a.display, NamedTextColor.RED));
                }
            }
        }
    }

    private void crown(Player p) {
        god = p.getUniqueId();
        broadcast("\u26A1 " + p.getName() + " reached AGE " + godAge() + " and is now the GOD of the server! \u26A1",
                NamedTextColor.GOLD);
        for (Player o : Bukkit.getOnlinePlayers()) {
            o.showTitle(Title.title(
                    Component.text("AGE " + godAge(), NamedTextColor.GOLD),
                    Component.text(p.getName() + " is now GOD", NamedTextColor.YELLOW)));
            o.playSound(o.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1f);
        }
        new BukkitRunnable() {
            int i = 0;

            @Override
            public void run() {
                if (!p.isOnline() || i++ >= 5) {
                    cancel();
                    return;
                }
                Location l = p.getLocation();
                l.getWorld().strikeLightningEffect(l);
                l.getWorld().spawnParticle(Particle.END_ROD, l.clone().add(0, 1, 0), 80, 0.6, 1, 0.6, 0.1);
            }
        }.runTaskTimer(this, 0L, 10L);
        saveData();
    }

    private void updateTab(Player p) {
        if (!getConfig().getBoolean("show-age-in-tab", true)) return;
        int age = getAge(p.getUniqueId());
        NamedTextColor col = p.getUniqueId().equals(god) ? NamedTextColor.GOLD
                : age >= 50 ? NamedTextColor.RED
                : age >= 30 ? NamedTextColor.LIGHT_PURPLE
                : age >= 20 ? NamedTextColor.AQUA
                : NamedTextColor.GRAY;
        p.playerListName(Component.text("[Age " + age + "] ", col)
                .append(Component.text(p.getName(), NamedTextColor.WHITE)));
    }

    // ------------------------------------------------------------ ability wand

    private ItemStack wand() {
        return wand(null);
    }

    private boolean packEnabled() {
        return getConfig().getBoolean("resource-pack.enabled", false);
    }

    /** Switches the wand's texture to match the ability (needs the resource pack). */
    private void applyModel(ItemMeta m, Ability a) {
        if (!packEnabled()) return;
        m.setItemModel(NamespacedKey.fromString("agesmp:" + (a == null ? "wand" : "wand_" + a.key)));
    }

    private void refreshWand(Player p, Ability a) {
        ItemStack held = p.getInventory().getItemInMainHand();
        if (!isWand(held)) return;
        ItemMeta m = held.getItemMeta();
        applyModel(m, a);
        held.setItemMeta(m);
    }

    private void sendPack(Player p) {
        if (!packEnabled()) return;
        String url = getConfig().getString("resource-pack.url", "");
        if (url == null || url.isBlank()) return;
        String sha1 = getConfig().getString("resource-pack.sha1", "");
        p.setResourcePack(url, (sha1 == null || sha1.isBlank()) ? null : sha1.trim(),
                getConfig().getBoolean("resource-pack.required", false),
                Component.text("Age SMP texture pack (custom Ability Wand)", NamedTextColor.GOLD));
    }

    private ItemStack wand(Ability a) {
        ItemStack it = new ItemStack(Material.BLAZE_ROD);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("Ability Wand", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text("Right-click: use selected ability", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Shift + Right-click: switch ability", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        m.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
        applyModel(m, a);
        it.setItemMeta(m);
        return it;
    }

    private boolean isWand(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE);
    }

    private void giveWandIfNeeded(Player p) {
        if (unlocked(p).isEmpty()) return;
        for (ItemStack it : p.getInventory().getContents()) {
            if (isWand(it)) return;
        }
        Map<Integer, ItemStack> left = p.getInventory().addItem(wand());
        left.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
    }

    // ------------------------------------------------------------ events

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        ages.putIfAbsent(p.getUniqueId(), startAge());
        names.put(p.getUniqueId(), p.getName());
        updateTab(p);
        giveWandIfNeeded(p);
        sendPack(p);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            updateTab(p);
            giveWandIfNeeded(p);
        }, 1L);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player v = e.getEntity();
        Player k = v.getKiller();
        e.getDrops().removeIf(this::isWand);

        boolean pvpKill = k != null && !k.equals(v);
        if (pvpKill || getConfig().getBoolean("death-loss-from-environment", true)) {
            setAge(v, getAge(v.getUniqueId()) - ci("death-loss", 2));
        }

        if (pvpKill) {
            long now = System.currentTimeMillis();
            Map<UUID, Long> m = lastKill.computeIfAbsent(k.getUniqueId(), x -> new HashMap<>());
            Long last = m.get(v.getUniqueId());
            long cooldown = ci("same-victim-cooldown-seconds", 300) * 1000L;
            if (last == null || now - last >= cooldown) {
                m.put(v.getUniqueId(), now);
                setAge(k, getAge(k.getUniqueId()) + ci("kill-gain", 1));
            } else {
                bar(k, "No Age gained: you killed this player too recently.");
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        if (!isWand(p.getInventory().getItemInMainHand())) return;
        e.setCancelled(true);

        List<Ability> list = unlocked(p);
        if (list.isEmpty()) {
            bar(p, "Reach Age " + unlockAge(Ability.CAGE) + " to unlock your first ability.");
            return;
        }
        UUID id = p.getUniqueId();
        int idx = selected.getOrDefault(id, 0) % list.size();
        if (p.isSneaking()) {
            idx = (idx + 1) % list.size();
            selected.put(id, idx);
            refreshWand(p, list.get(idx));
            bar(p, "Selected: " + list.get(idx).display);
            return;
        }
        selected.put(id, idx);
        refreshWand(p, list.get(idx));
        use(p, list.get(idx));
    }

    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity victim)) return;
        Long until = titanUntil.get(p.getUniqueId());
        if (until == null) return;
        if (until < System.currentTimeMillis()) {
            titanUntil.remove(p.getUniqueId());
            return;
        }
        String held = p.getInventory().getItemInMainHand().getType().name();
        if (!held.endsWith("_AXE") && !held.equals("MACE")) return;

        titanUntil.remove(p.getUniqueId());
        e.setDamage(e.getDamage() + cd("abilities.titan.bonus-damage", 20));
        Location l = victim.getLocation().add(0, 1, 0);
        l.getWorld().spawnParticle(Particle.CRIT, l, 60, 0.4, 0.6, 0.4, 0.4);
        l.getWorld().playSound(l, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 1.6f);
    }

    @EventHandler
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL || !(e.getEntity() instanceof Player p)) return;
        Long until = noFallUntil.get(p.getUniqueId());
        if (until != null && until > System.currentTimeMillis()) {
            e.setCancelled(true);
            noFallUntil.remove(p.getUniqueId());
        }
    }

    // --- keep cage / lava box blocks from being broken, exploded or bucketed

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (protectedBlocks.contains(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> protectedBlocks.contains(b.getLocation()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> protectedBlocks.contains(b.getLocation()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (protectedBlocks.contains(e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (protectedBlocks.contains(e.getBlock().getLocation())) e.setCancelled(true);
    }

    // ------------------------------------------------------------ abilities

    private void use(Player p, Ability a) {
        long now = System.currentTimeMillis();
        String ck = p.getUniqueId() + ":" + a.key;
        Long until = cooldowns.get(ck);
        if (until != null && until > now) {
            bar(p, a.display + " cooldown: " + ((until - now) / 1000 + 1) + "s");
            return;
        }
        boolean ok = switch (a) {
            case CAGE -> cage(p);
            case LAVA -> lavaTrap(p);
            case LEAP -> leap(p);
            case TITAN -> titan(p);
        };
        if (ok) cooldowns.put(ck, now + ci("abilities." + a.key + ".cooldown", 30) * 1000L);
    }

    /** Player in the crosshair (blocks in the way stop the ray). */
    private Player target(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTrace(eye, eye.getDirection(), range,
                FluidCollisionMode.NEVER, true, 0.6,
                en -> en instanceof Player pl && !pl.equals(p) && pl.getGameMode() != GameMode.SPECTATOR);
        Player t = (r != null && r.getHitEntity() instanceof Player hit) ? hit : null;
        if (t == null) {
            bar(p, "No player in sight!");
            return null;
        }
        if (!t.getWorld().getPVP()) {
            bar(p, "PvP is disabled right now.");
            return null;
        }
        return t;
    }

    private Location centerOf(Location blockLoc, Player t) {
        Location l = blockLoc.clone().add(0.5, 0, 0.5);
        l.setYaw(t.getLocation().getYaw());
        l.setPitch(t.getLocation().getPitch());
        return l;
    }

    /** Age 20: Obsidian Cage. 3x3 cage, 2 blocks tall inside, around the target. */
    private boolean cage(Player p) {
        Player t = target(p, cd("abilities.cage.range", 25));
        if (t == null) return false;

        Location c = t.getLocation().getBlock().getLocation();
        TempBlocks box = new TempBlocks();
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 2; y++) {
                for (int z = -1; z <= 1; z++) {
                    boolean inside = x == 0 && z == 0 && (y == 0 || y == 1);
                    if (inside) continue;
                    box.set(c.clone().add(x, y, z).getBlock(), Material.OBSIDIAN);
                }
            }
        }
        t.teleport(centerOf(c, t));
        schedule(box, ci("abilities.cage.duration", 8));

        t.getWorld().playSound(t.getLocation(), Sound.BLOCK_ANVIL_LAND, 1f, 0.6f);
        t.sendMessage(Component.text(p.getName() + " trapped you in an Obsidian Cage!", NamedTextColor.RED));
        bar(p, "Obsidian Cage!");
        return true;
    }

    /** Age 30: Lava Trap. 3x3x3 lava box sealed inside an obsidian shell. */
    private boolean lavaTrap(Player p) {
        Player t = target(p, cd("abilities.lava.range", 25));
        if (t == null) return false;

        Location c = t.getLocation().getBlock().getLocation();
        TempBlocks box = new TempBlocks();
        for (int x = -2; x <= 2; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    boolean shell = Math.max(Math.abs(x), Math.max(Math.abs(y), Math.abs(z))) == 2;
                    box.set(c.clone().add(x, y, z).getBlock(), shell ? Material.OBSIDIAN : Material.LAVA);
                }
            }
        }
        t.teleport(centerOf(c, t));
        schedule(box, ci("abilities.lava.duration", 5));

        t.getWorld().playSound(t.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 0.8f);
        t.sendMessage(Component.text(p.getName() + " dropped you into a Lava Trap!", NamedTextColor.RED));
        bar(p, "Lava Trap!");
        return true;
    }

    /** Age 40: Warrior Leap. Jump high, smash enemies on landing. */
    private boolean leap(Player p) {
        Vector d = p.getLocation().getDirection();
        d.setY(0);
        if (d.lengthSquared() < 1e-4) {
            d = new Vector(0, 0, 0);
        } else {
            d.normalize().multiply(cd("abilities.leap.forward", 0.8));
        }
        d.setY(cd("abilities.leap.height", 1.1));
        p.setVelocity(d);
        noFallUntil.put(p.getUniqueId(), System.currentTimeMillis() + 10_000L);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.6f, 1.4f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                ticks++;
                if (!p.isOnline() || p.isDead() || ticks > 100) {
                    cancel();
                    return;
                }
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 3, 0.2, 0.1, 0.2, 0.01);
                if (ticks > 5 && onGround(p)) {
                    smash(p);
                    cancel();
                }
            }
        }.runTaskTimer(this, 1L, 1L);
        return true;
    }

    private boolean onGround(Player p) {
        return p.getLocation().clone().subtract(0, 0.15, 0).getBlock().getType().isSolid();
    }

    private void smash(Player p) {
        Location l = p.getLocation();
        double r = cd("abilities.leap.radius", 4);
        double dmg = cd("abilities.leap.damage", 8);
        l.getWorld().spawnParticle(Particle.CLOUD, l, 60, r / 2, 0.2, r / 2, 0.05);
        l.getWorld().spawnParticle(Particle.CRIT, l, 40, r / 2, 0.5, r / 2, 0.2);
        l.getWorld().playSound(l, Sound.BLOCK_ANVIL_LAND, 1f, 0.7f);
        if (!l.getWorld().getPVP()) return;
        for (Entity en : l.getWorld().getNearbyEntities(l, r, r, r)) {
            if (en instanceof Player t && !t.equals(p) && t.getGameMode() != GameMode.SPECTATOR) {
                t.damage(dmg, p);
                t.setVelocity(new Vector(0, 0.6, 0));
            }
        }
    }

    /** Age 50: Titan Smash. Next axe / mace hit within the window deals huge bonus damage. */
    private boolean titan(Player p) {
        int window = ci("abilities.titan.window", 10);
        titanUntil.put(p.getUniqueId(), System.currentTimeMillis() + window * 1000L);
        p.sendMessage(Component.text("Titan Smash armed! Your next axe/mace hit within " + window
                + "s will be devastating.", NamedTextColor.GOLD));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 1.5f);
        p.getWorld().spawnParticle(Particle.FLAME, p.getLocation().add(0, 1, 0), 40, 0.4, 0.8, 0.4, 0.05);
        return true;
    }

    // ------------------------------------------------------------ temporary blocks

    /** Remembers the original blocks so cages / lava boxes can be put back exactly. */
    private class TempBlocks {
        private final Map<Location, BlockData> saved = new LinkedHashMap<>();

        void set(Block b, Material m) {
            Location l = b.getLocation();
            if (protectedBlocks.contains(l)) return;
            Material t = b.getType();
            if (t == Material.BEDROCK || t == Material.END_PORTAL_FRAME || t == Material.END_PORTAL
                    || t == Material.NETHER_PORTAL || b.getState() instanceof TileState) {
                return; // never overwrite chests, spawners, portals, bedrock...
            }
            saved.put(l, b.getBlockData());
            protectedBlocks.add(l);
            b.setType(m, false);
        }

        void restore() {
            for (Map.Entry<Location, BlockData> en : saved.entrySet()) {
                en.getKey().getBlock().setBlockData(en.getValue(), false);
                protectedBlocks.remove(en.getKey());
            }
            saved.clear();
            active.remove(this);
        }
    }

    private void schedule(TempBlocks box, int seconds) {
        active.add(box);
        Bukkit.getScheduler().runTaskLater(this, box::restore, seconds * 20L);
    }

    // ------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String sub = a.length == 0 ? "info" : a[0].toLowerCase();
        switch (sub) {
            case "info" -> info(s);
            case "top" -> top(s);
            case "wand" -> wandCmd(s);
            case "start" -> {
                if (admin(s)) startCmd();
            }
            case "stop" -> {
                if (admin(s)) {
                    for (World w : Bukkit.getWorlds()) w.setPVP(false);
                    broadcast("PVP DISABLED", NamedTextColor.GREEN);
                }
            }
            case "set" -> {
                if (admin(s)) setCmd(s, a);
            }
            case "reset" -> {
                if (admin(s)) resetCmd(s, a);
            }
            case "reload" -> {
                if (admin(s)) {
                    reloadConfig();
                    msg(s, "Config reloaded.", NamedTextColor.GREEN);
                }
            }
            default -> msg(s, "Usage: /age [info|top|wand|start|stop|set|reset|reload]", NamedTextColor.RED);
        }
        return true;
    }

    private boolean admin(CommandSender s) {
        if (s.hasPermission("age.admin")) return true;
        msg(s, "You don't have permission.", NamedTextColor.RED);
        return false;
    }

    private void info(CommandSender s) {
        if (!(s instanceof Player p)) {
            msg(s, "Players only.", NamedTextColor.RED);
            return;
        }
        int age = getAge(p.getUniqueId());
        msg(p, "Your Age: " + age + (p.getUniqueId().equals(god) ? "  (GOD)" : ""), NamedTextColor.GOLD);
        for (Ability ab : Ability.values()) {
            int u = unlockAge(ab);
            boolean ok = age >= u;
            msg(p, (ok ? "\u2714 " : "\u2718 ") + ab.display + " (Age " + u + ")",
                    ok ? NamedTextColor.GREEN : NamedTextColor.GRAY);
        }
        if (god != null) msg(p, "GOD: " + names.getOrDefault(god, "?"), NamedTextColor.YELLOW);
    }

    private void top(CommandSender s) {
        List<Map.Entry<UUID, Integer>> list = new ArrayList<>(ages.entrySet());
        list.sort((x, y) -> Integer.compare(y.getValue(), x.getValue()));
        msg(s, "--- Age Leaderboard ---", NamedTextColor.GOLD);
        int i = 1;
        for (Map.Entry<UUID, Integer> en : list) {
            if (i > 10) break;
            msg(s, i + ". " + names.getOrDefault(en.getKey(), "?") + " - Age " + en.getValue(),
                    NamedTextColor.WHITE);
            i++;
        }
    }

    private void wandCmd(CommandSender s) {
        if (!(s instanceof Player p)) {
            msg(s, "Players only.", NamedTextColor.RED);
            return;
        }
        if (unlocked(p).isEmpty() && !p.hasPermission("age.admin")) {
            msg(p, "Reach Age " + unlockAge(Ability.CAGE) + " first.", NamedTextColor.RED);
            return;
        }
        for (ItemStack it : p.getInventory().getContents()) {
            if (isWand(it)) {
                msg(p, "You already have the Ability Wand.", NamedTextColor.YELLOW);
                return;
            }
        }
        Map<Integer, ItemStack> left = p.getInventory().addItem(wand());
        left.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
    }

    private void startCmd() {
        for (int i = 3; i >= 1; i--) {
            final int n = i;
            Bukkit.getScheduler().runTaskLater(this, () -> {
                for (Player o : Bukkit.getOnlinePlayers()) {
                    o.showTitle(Title.title(
                            Component.text(String.valueOf(n), NamedTextColor.YELLOW),
                            Component.text("Age SMP is starting...", NamedTextColor.GRAY)));
                    o.playSound(o.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
                }
            }, (3 - i) * 20L);
        }
        Bukkit.getScheduler().runTaskLater(this, () -> {
            for (World w : Bukkit.getWorlds()) w.setPVP(true);
            for (Player o : Bukkit.getOnlinePlayers()) {
                o.showTitle(Title.title(
                        Component.text("PVP ENABLED", NamedTextColor.RED),
                        Component.text("Hunt to survive.", NamedTextColor.GRAY)));
                o.playSound(o.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1f);
            }
            broadcast("PVP ENABLED", NamedTextColor.RED);
        }, 60L);
    }

    private void setCmd(CommandSender s, String[] a) {
        if (a.length < 3) {
            msg(s, "Usage: /age set <player> <age>", NamedTextColor.RED);
            return;
        }
        Player t = Bukkit.getPlayerExact(a[1]);
        if (t == null) {
            msg(s, "Player not online.", NamedTextColor.RED);
            return;
        }
        try {
            setAge(t, Integer.parseInt(a[2]));
            msg(s, t.getName() + " is now Age " + getAge(t.getUniqueId()) + ".", NamedTextColor.GREEN);
        } catch (NumberFormatException ex) {
            msg(s, "Age must be a number.", NamedTextColor.RED);
        }
    }

    private void resetCmd(CommandSender s, String[] a) {
        if (a.length < 2 || !a[1].equalsIgnoreCase("confirm")) {
            msg(s, "This wipes ALL ages and the GOD title. Run /age reset confirm to proceed.",
                    NamedTextColor.RED);
            return;
        }
        ages.clear();
        names.clear();
        selected.clear();
        cooldowns.clear();
        lastKill.clear();
        god = null;
        for (Player p : Bukkit.getOnlinePlayers()) {
            ages.put(p.getUniqueId(), startAge());
            names.put(p.getUniqueId(), p.getName());
            updateTab(p);
        }
        saveData();
        msg(s, "Age SMP has been reset.", NamedTextColor.GREEN);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            List<String> subs = new ArrayList<>(List.of("info", "top", "wand"));
            if (s.hasPermission("age.admin")) subs.addAll(List.of("start", "stop", "set", "reset", "reload"));
            for (String x : subs) if (x.startsWith(a[0].toLowerCase())) out.add(x);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("set") && s.hasPermission("age.admin")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(a[1].toLowerCase())) out.add(p.getName());
            }
        }
        return out;
    }

    // ------------------------------------------------------------ persistence

    private void loadData() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        String g = y.getString("god");
        if (g != null) {
            try {
                god = UUID.fromString(g);
            } catch (IllegalArgumentException ignored) {
                god = null;
            }
        }
        ConfigurationSection sec = y.getConfigurationSection("players");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                ages.put(id, sec.getInt(key + ".age", startAge()));
                names.put(id, sec.getString(key + ".name", "?"));
            } catch (IllegalArgumentException ignored) {
                // skip bad entries
            }
        }
    }

    private void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        if (god != null) y.set("god", god.toString());
        for (Map.Entry<UUID, Integer> en : ages.entrySet()) {
            String base = "players." + en.getKey();
            y.set(base + ".age", en.getValue());
            y.set(base + ".name", names.getOrDefault(en.getKey(), "?"));
        }
        try {
            getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("Could not save data.yml: " + ex.getMessage());
        }
    }
}
